#ifndef ERROS_H
    #define ERROS_H

    #define STR_VAZIA "NULO"

    void erroGenerico();
    void erroSemRegistros();
    void erroModo();
    
#endif