#ifndef ERROS_H
    #define ERROS_H

    void erroGenerico();
    void erroSemRegistros();
    void erroModo();
    
#endif