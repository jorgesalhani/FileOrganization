#ifndef FUNCOES_FORNECIDAS_H
    #define FUNCOES_FORNECIDAS_H

    void readline(char *string);
    void binarioNaTela(char *nomeArquivoBinario);
    void scan_quote_string(char *str);

#endif