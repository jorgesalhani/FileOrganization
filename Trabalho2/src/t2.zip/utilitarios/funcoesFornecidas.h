#ifndef FUNCOES_FORNECIDAS_H
    #define FUNCOES_FORNECIDAS_H

    #include <stdbool.h>
    #include "erros.h"

    void readline(char *string);
    void binarioNaTela(char *nomeArquivoBinario);
    void scan_quote_string(char *str);

#endif